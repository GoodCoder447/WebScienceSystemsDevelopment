Parker Slote
slotep 

Probably one of the most annoying labs I've had to do. Jumped through
so many hoops to get geolocation to work. Eventually just created a 
self signed certifacte for local host. Also I feel like the lab itself
had me spend more time on formatting the correct JSON format that actually
figuring out how to use an API call. Other than that, was pretty easy, 
was pretty similar to last lab. Only had to visit the bootstrap documentation
for the col-md-X formats.